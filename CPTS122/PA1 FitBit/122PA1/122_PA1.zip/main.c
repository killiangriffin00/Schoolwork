/*
	NAME: Killian Griffin
	CLASS: CptS121, Spring 2020, Lab Section 5
	ASSIGNMENT: PA1
	DATE: 1/23/20
	DESCRIPTION: This program reads and parces FitBit activity data from a file and outputs total calories burned, distance walked in 
				 miles, floors walked, steps taken, average heart rate, max steps over a minute interval, and longest range of poor 
				 sleep.
*/

#include "header.h"

int main(void)
{
	FitbitData array[1444]; 
	FILE* infile = NULL, * outfile = NULL;
	int count = 0, maxConsecutive = 0, check = 0, maxSteps = 0, totalFloors = 0, 
		totalSteps = 0, totalHeartRate = 0, avgHeartRate = 0;                         // variables defined and initialized
	double totalCalories = 0, totalDistance = 0;
	char rangeStart[9] = { '\0' }, rangeEnd[9] = { '0' }, newRangeStart[9] = { '\0' };
		
	infile = fopen("FitbitData.csv", "r"); // input file set to FitbitData.csv
	
	readFitbitData(array, infile); // function reads and parces data into array of fitbit data
	
	fclose(infile); //file is closed

	for (int index = 0; index < 1444; ++index) // loop is used to calculate totals for each set of data
	{
		if (array[index].distance > 0) // if statements are for discluding any invalid values in the data set
		{
			totalDistance = totalDistance + array[index].distance;
		}
		if (array[index].floors > 0)
		{
			totalFloors = totalFloors + array[index].floors;
		}
		if (array[index].steps > 0)
		{
			totalSteps = totalSteps + array[index].steps;
		}
		if (array[index].calories > 0)
		{
			totalCalories = totalCalories + array[index].calories;
		}
	}
	for (int index = 0; index < 1444; ++index) // loop used to calculate average heart rate
	{
		if (array[index].heartRate < 1000) // if statement used to disclude any invalid values in the data set
		{
			++count;
			totalHeartRate = totalHeartRate + array[index].heartRate; // total is calculated first
		}
	}
	avgHeartRate = totalHeartRate / count; // average is calculated dividing the ammount of valid values

	maxSteps = array[0].steps; // base comparison must be used 
	for (int index = 0; index < 1444; ++index) // loop used to calculate maximum steps taken in a minute
	{
		if (array[index].steps >= maxSteps)
		{
			maxSteps = array[index].steps;
		}

	}

	count = 0; // count variable re-initialized for use in this loop
	for (int index = 0; index < 1444; ++index) // loop used to calculate range of worst sleep
	{
		if (array[index].sleepLevel < 1)
		{
			if (count == 0)
			{
				strcpy(newRangeStart, array[index].minute);
			}
			++count;
		}
		else
		{
			if (count > maxConsecutive)
			{
				maxConsecutive = count;
				strcpy(rangeStart, newRangeStart);
				strcpy(rangeEnd, array[index].minute);
			}
		}
	}
	outfile = fopen("Results.csv", "w"); // output file set to Results.csv
	fprintf(outfile, "Total Calories, Total Distance, Total Floors, Total Steps, Avg Heartrate, Max Steps, Sleep\n"); 
	fprintf(outfile, "%lf, %lf, %d, %d, %d, %d, %s, %s", totalCalories, totalDistance, totalFloors, totalSteps, avgHeartRate, maxSteps, rangeStart, rangeEnd);
	// results printed to output file
	fclose(outfile); // output file closed
	return 0;
}