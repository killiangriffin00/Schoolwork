/*
	NAME: Killian Griffin
	CLASS: CptS121, Spring 2020, Lab Section 5
	ASSIGNMENT: PA1
	DATE: 1/23/20
	DESCRIPTION: This program reads and parces FitBit activity data from a file and outputs total calories burned, distance walked in
				 miles, floors walked, steps taken, average heart rate, max steps over a minute interval, and longest range of poor
				 sleep.
*/

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <math.h>
#include <string.h>

typedef enum sleep
{
	NONE = 0, ASLEEP = 1, AWAKE = 2, REALLYAWAKE = 3
} Sleep;

typedef struct fitbit
{
	char patient[10];
	char minute[9];
	double calories;
	double distance;
	unsigned int floors;
	unsigned int heartRate;
	unsigned int steps;
	Sleep sleepLevel;
} FitbitData;

void readFitbitData(FitbitData array[], FILE* infile);
