/*
	NAME: Killian Griffin
	CLASS: CptS121, Spring 2020, Lab Section 5
	ASSIGNMENT: PA1
	DATE: 1/23/20
	DESCRIPTION: This program reads and parces FitBit activity data from a file and outputs total calories burned, distance walked in
				 miles, floors walked, steps taken, average heart rate, max steps over a minute interval, and longest range of poor
				 sleep.
*/

#include "header.h"
/*
/	FUNCTION: "readFitbitData"
/	DATE LAST MODIFIED: 1/24/20
/	EXPECTED INPUT: Array of FitbitData structs, input file
/	EXPECTED OUTPUT: None
/	DESCRIPTION: Used to read the data from a .csv file into the FitbitData array and parse it into the corresponding data types
*/
void readFitbitData(FitbitData array[], FILE* infile)
{
	int index2 = 0, lineInt[5], check = 0;
	char toptext[80], trash = '/0';         // variables defined and initialized
	double  lineFloat[5];

	fgets(toptext, 80, infile); // scans through text at top to start at actual data

	for (int index1 = 0; index1 < 1444; ++index1) // loop executed for each minute of the 24-hour time period
	{
		for (int initialize = 0; initialize < 5; ++initialize) // initializes (re-initializes) arrays used to read in float-point and
		{                                                      // integer values. Initialized at -1 to make sure values are set as invalid
			lineInt[initialize] = -1;                          // values if function fails to read in a value
			lineFloat[initialize] = -1;
		}
		if (check == 1)                                     // if statement used to correct errors where the function reads values
		{                                                   // at the start of the new line if there is no sleep value
			index2 = 3;
			array[index1].patient[0] = array[0].patient[0];
			array[index1].patient[1] = array[0].patient[1];
			array[index1].patient[2] = array[0].patient[2];
			check = 0;
		}
		for (; array[index1].patient[index2 - 1] != ','; ++index2) // for statements used to read directly into the patient and minute
		{                                                          // strings character by character until it encounters a comma
			fscanf(infile, "%c", &array[index1].patient[index2]);
		}
		array[index1].patient[index2 - 1] = '\0'; // comma previously read is replaced with a null character, terminating the string

		for (index2 = 0; array[index1].minute[index2 - 1] != ','; ++index2)
		{
			fscanf(infile, "%c", &array[index1].minute[index2]);
		}
		array[index1].minute[index2 - 1] = '\0';

		for (index2 = 0; index2 < 2; ++index2) // for loops used to read float and integer values into respective arrays
		{
			fscanf(infile, "%lf", &lineFloat[index2]);
			fscanf(infile, "%c", &trash); // statement used to scan over comma and continue to next value
		}
		for (index2 = 0; index2 < 3; ++index2)
		{
			fscanf(infile, "%d", &lineInt[index2]);
			fscanf(infile, "%c", &trash);
		}

		fscanf(infile, "%d", &lineInt[index2]); // used to find last value in file line before new line
		fscanf(infile, "%c", &trash); 
		if (lineInt[index2] > 3) // used to filter invalid values
		{
			lineInt[index2] = -1;
			if (trash != 10) // used to detect if no value was in this position in the file
			{
				check = 1;
			}
		}


		array[index1].calories = lineFloat[0]; // values in the struct are set to their respective values in the arrays where the 
		array[index1].distance = lineFloat[1]; // file informatin was written to

		array[index1].floors = lineInt[0];
		array[index1].heartRate = lineInt[1];
		array[index1].steps = lineInt[2];
		array[index1].sleepLevel = lineInt[3];
		index2 = 0;
	}
}

		
	

/*
if (index1 < 1444)
{
	for (index2 = 0; array[index1 + 1].patient[index2 - 1] != ','; ++index2)
	{
		(infile, "s", &array[index1 + 1].patient[index2]);
	}
	if (index2 > 5)
	{
		array[index1].sleepLevel = array[index1 + 1].patient[0];
		array[index1 + 1].patient[index2] = NULL;
	}
	else
	{
		if (array[index1 + 1].patient[0] == '0')
		{
			array[index1].sleepLevel = 0;
		}
		if (array[index1 + 1].patient[0] == '1')
		{
			array[index1].sleepLevel = 1;
		}
		if (array[index1 + 1].patient[0] == '2')
		{
			array[index1].sleepLevel = 2;
		}
		if (array[index1 + 1].patient[0] == '3')
		{
			array[index1].sleepLevel = 3;
		}
	}
}
else
{
	fscanf(infile, "%d", &array[index1].sleepLevel);
}

fscanf(infile, "%d", &array[index1].floors);
		if (array[index1].floors > 1000)
		{
			array[index1].floors = -1;
		}
		else
		{
			fscanf(infile, "%c", &trash);
		}
*/